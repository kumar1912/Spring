package main.java.com.learnjava.domain.checkout;

public enum CheckoutStatus {
    SUCCESS,
    FAILURE
}
