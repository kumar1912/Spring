package main.java.com.learnjava.service;

import main.java.com.learnjava.domain.ProductInfo;
import main.java.com.learnjava.domain.ProductOption;

import java.util.List;

import static main.java.com.learnjava.util.CommonUtil.delay;

public class ProductInfoService {

    public ProductInfo retrieveProductInfo(String productId) {
        delay(1000);
        List<ProductOption> productOptions = List.of(new ProductOption(1, "64GB", "Black", 699.99),
                new ProductOption(2, "128GB", "Black", 749.99),
                new ProductOption(3, "256GB", "Black", 699.99),
                new ProductOption(4, "512GB", "Black", 749.99));
        return ProductInfo.builder().productId(productId)
                .productOptions(productOptions)
                .build();
    }
    
  public static void main(String[] args) {
	  ProductInfoService  productInfoService = new ProductInfoService();
	  ProductInfo productInfo = productInfoService.retrieveProductInfo("2");
	 System.out.println("productInfo : " + productInfo);
   }
}
