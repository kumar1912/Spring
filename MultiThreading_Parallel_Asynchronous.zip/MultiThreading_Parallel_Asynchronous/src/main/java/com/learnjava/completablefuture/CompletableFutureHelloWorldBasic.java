package main.java.com.learnjava.completablefuture;

import static main.java.com.learnjava.util.LoggerUtil.log;
import static main.java.com.learnjava.util.CommonUtil.*;
import java.util.concurrent.CompletableFuture;

import main.java.com.learnjava.service.HelloWorldService;


public class CompletableFutureHelloWorldBasic {
	public static void main(String[] args) {

		HelloWorldService hws = new HelloWorldService();

		CompletableFuture.supplyAsync(() -> hws.helloWorld())
		.thenAccept((result) -> {
			log("Result is " + result);
		});
		log("Done!");
		delay(2000);

		/* 
        HelloWorldService hws = new HelloWorldService();

        CompletableFuture.supplyAsync(() -> hws.helloWorld())
                .thenAccept((result) -> {
                    log("Result is " + result);
                })
                .join();
        log("Done!");
        //delay(2000);

		 */
		//11. Exploring CompletableFuture Functions : 2. Transform Data using thenApply()
		
      // CompletableFuture.supplyAsync(() -> hws.helloWorld())
		 //        or
		CompletableFuture.supplyAsync(hws::helloWorld)
		.thenApply(String::toUpperCase)
		.thenAccept((result) -> {
			log("Result is : " + result);
		})
		.join();
		log("Done!");
		delay(2000);
	}

	/*
	private static void delay(int i) {
		// TODO Auto-generated method stub

	}
	 */
}
