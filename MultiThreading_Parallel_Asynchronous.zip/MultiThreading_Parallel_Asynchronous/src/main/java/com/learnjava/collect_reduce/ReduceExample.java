package main.java.com.learnjava.collect_reduce;

import java.util.List;

public class ReduceExample {

    public  int reduce_sum_ParallelStream(List<Integer> inputList){

        int sum= inputList
                .parallelStream()  //very important stream() and parallelStream()
                //.reduce(1, (x,y)->x+y);
                .reduce(0, (x,y)->x+y);
        return sum;
    }

    public  int reduce_multiply_parallelStream(List<Integer> inputList){
        int multiply= inputList
                .parallelStream()
                .reduce(1, (x,y)->x*y);
        return multiply;
    }

}