package test.java.com.learnjava.completablefuture;

import main.java.com.learnjava.service.HelloWorldService;
import main.java.com.learnjava.completablefuture.CompletableFutureHelloWorld;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;

class CompletableFutureHelloWorldBasicTest {

    HelloWorldService hws = new HelloWorldService();
    CompletableFutureHelloWorld cfhw = new CompletableFutureHelloWorld(hws);
    @Test
    void helloWorld() {
        //given

        //when
        CompletableFuture<String> completableFuture = cfhw.helloWorld();

        //then
        completableFuture
                .thenAccept(s -> {
                    assertEquals("HELLO WORLD", s);
//                    assertEquals("HELLO WORLD1", s);
                })
                .join();
    }
    
    @Test
    void helloworld_muliple_async_calls() {
        //given

        //when
        String helloWorld = cfhw.helloworld_muliple_async_calls();

        //then
//        assertEquals("HELLO WORLD! 1", helloWorld);
        assertEquals("HELLO WORLD!", helloWorld);
    }

    @Test
    void helloworld_3_async_calls() {
        //given

        //when
        String helloWorld = cfhw.helloworld_3_async_calls();

        //then
        assertEquals("HELLO WORLD! HI COMPLETABLEFUTURE!", helloWorld);
    }
}