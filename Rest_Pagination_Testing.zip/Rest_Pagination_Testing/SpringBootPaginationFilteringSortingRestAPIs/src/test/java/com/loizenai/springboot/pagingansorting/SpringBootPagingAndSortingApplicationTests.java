package com.loizenai.springboot.pagingansorting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPagingAndSortingApplicationTests {

	@Test
	void contextLoads() {
	}

}
