package com.rest;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class TestRest {

    @Test
    public void test(){
        given().
        when().
        then();
    }
}
