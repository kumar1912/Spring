package com.rest;

public interface MyInterface {

    MyInterface printMe();
}
