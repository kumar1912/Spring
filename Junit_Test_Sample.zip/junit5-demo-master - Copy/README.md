# junit5-demo

### Status
[![Build Status](https://api.travis-ci.org/arindamnayak/junit5-demo.svg?branch=master)](https://travis-ci.org/arindamnayak/junit5-demo/builds)

### Disclaimer
This repo is soley to demo junit 5 features, application only contains service class which has CRUD for emploee with certain validation which is being tested.

#### Demo for new features in junit5, following features covered in this demo.
- Assertions with lambda
- tagging of test
- nested testcases
- parameterized test
- dynamic display name for test
- dynamic test using test factory.

#### To run the application. 
- gradle test
