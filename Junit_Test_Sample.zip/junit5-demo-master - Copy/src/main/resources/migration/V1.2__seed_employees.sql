INSERT INTO `Employee` (`id`, `first_name`, `last_name`, `email`)
VALUES
  (1, 'fname1', 'lname1', 'email1@exmaple.com');


INSERT INTO `Employee` (`id`, `first_name`, `last_name`, `email`)
VALUES
  (2, 'fname2', 'lname2', 'email2@exmaple.com');


INSERT INTO `Employee` (`id`, `first_name`, `last_name`, `email`)
VALUES
  (3, 'fname3', 'lname3', 'email3@exmaple.com');
