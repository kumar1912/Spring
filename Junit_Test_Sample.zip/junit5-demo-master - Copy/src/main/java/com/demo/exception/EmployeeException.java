package com.demo.exception;

public class EmployeeException extends Exception {

  public EmployeeException(String error) {
    super(error);
  }
}
